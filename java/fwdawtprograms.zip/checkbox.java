import java.awt.*; 
class checkbox
{
	public static void main(String[] args) 
	{
		Frame f=new Frame();
		f.setVisible(true);
		f.setSize(300,500);
		f.setBackground(Color.green);
		f.setTitle("Checkboxes and Ratio buttons");
		f.setLayout(new FlowLayout());
		
		String s="hello sir \n How are you..?";

		Label l1=new Label("Qualifications:");
		Label l2=new Label("Gender:");

		Checkbox cb1=new Checkbox("10th",true);
		Checkbox cb2=new Checkbox("inter");
		Checkbox cb3=new Checkbox("Mpcs");
		Checkbox cb4=new Checkbox("MSc");
		CheckboxGroup cg=new CheckboxGroup();
		Checkbox c1=new Checkbox("Male",cg,true);
		Checkbox c2=new Checkbox("Female",cg,false);
		System.out.println(c1.getLabel());

		TextArea ta=new TextArea(s,15,10);

		f.add(l1);
		f.add(cb1);
		f.add(cb2);
		f.add(cb3);
		f.add(cb4);
		f.add(l2);
		f.add(c1);
		f.add(c2);
		f.add(ta);		
	}
}