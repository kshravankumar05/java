import java.awt.*; 
class login 
{
	public static void main(String[] args) 
	{
		Frame f=new Frame();
		f.setVisible(true);
		f.setSize(400,200);
		f.setBackground(Color.green);
		f.setTitle("LoginPage");
		f.setLayout(new FlowLayout());

		Label l1=new Label("User name:");
		Label l2=new Label("Password:");

		TextField tx1=new TextField(30);
		TextField tx2=new TextField(30);
		tx2.setEchoChar('&');

		Button b1=new Button("Login");

		f.add(l1);
		f.add(tx1);
		f.add(l2);
		f.add(tx2);
		f.add(b1);
		
	}
}