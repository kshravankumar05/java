import java.awt.*; 
class Awt1 
{
	public static void main(String[] args) 
	{
		// create of Frame
		Frame f=new Frame();
		f.setVisible(true);
		f.setSize(300,500);
		f.setBackground(Color.green);
		f.setTitle("chandu designs");
		
	}
}
