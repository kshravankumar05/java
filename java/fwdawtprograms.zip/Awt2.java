import java.awt.*; 
class Awt2 extends Frame 
{
	Awt2()
	{
		setVisible(true);
		setSize(200,300);
		setTitle("chandu");
		setBackground(Color.YELLOW);
	}
	public static void main(String[] args) 
	{
		Awt2 a=new Awt2();		
	}
}