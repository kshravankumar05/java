import java.awt.*; 
class ListChoice 
{
	public static void main(String[] args) 
	{
		Frame f=new Frame();
		f.setVisible(true);
		f.setSize(300,500);
		f.setBackground(Color.green);
		f.setTitle("Select content");
		f.setLayout(new FlowLayout());

		Label l1=new Label("Technologies:");
		Label l2=new Label("City:");

		List l=new List(1,true);
			l.add("Ms-office");
			l.add("C");
			l.add("C++");
			l.add("Java");
			l.add(".Net");
			l.add("Tally");
			l.remove("Tally");
			System.out.println(l.getItem(0));
			System.out.println(l.getItemCount());

			Choice ch=new Choice();
			ch.add("Hyderabad");
			ch.add("Rangareddy");
			ch.add("Khammam");
			ch.add("Warangal");
			ch.add("Nalgonda");
			ch.add("Karimnagar");
			ch.add("Mahabubnagar");
			ch.add("Kadapa");
			ch.remove("Kadapa");
			System.out.println(ch.getItem(0));
			System.out.println(ch.getItemCount());

			f.add(l1);
			f.add(l);
			f.add(l2);
			f.add(ch);
		
	}
}