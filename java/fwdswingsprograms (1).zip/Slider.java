import javax.swing.*;  
  
public class Slider extends JFrame{  
  
public Slider() {  
JSlider slider1 = new JSlider(JSlider.HORIZONTAL, 0, 50, 25);  
JSlider slider2 = new JSlider(JSlider.VERTICAL, 0, 50, 25);
JPanel panel=new JPanel();  
panel.add(slider1);  
panel.add(slider2);  
  
  add(panel);
  
}  
  
public static void main(String s[]) {  
Slider frame=new Slider(); 

frame.pack();  
frame.setVisible(true);  
}  
}  
